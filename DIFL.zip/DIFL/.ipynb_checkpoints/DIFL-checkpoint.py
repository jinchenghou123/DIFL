import torch
import numpy as np
from torch.utils.data import DataLoader
import sys
from datasets import Dataset
from model import Model
from metrics import xauc_score
from torch.optim import Adam
import copy
import torch.nn as nn
import torch.nn.functional as F
from sklearn.preprocessing import LabelEncoder
import random
import math



batch_size = 128
feat_dim = 32 # base model
dropout = 0.0
num_epochs = 20
learning_rate = 5e-4
regular_weight = 100

train_feats_selected = np.load("/root/KuaiRec_2.0/with_duration/train_kauiRec.npy")
test_feats_selected = np.load("/root/KuaiRec_2.0/with_duration/test_kauiRec.npy")


plays_train = train_feats_selected[:,-4]

#plays_train = np.minimum(plays_train, 60)

plays_test = test_feats_selected[:,-4]

duration_train = train_feats_selected[:,-3]
duration_test = test_feats_selected[:,-3]
 

quantiles = np.linspace(0,1,31)
bins = np.quantile(duration_train, quantiles)


# min_val = duration_train.min()
# max_val = duration_train.max()

# bins = np.linspace(min_val, 60, 31)  # equal width
# bins[-1] = max_val

bin_train = np.digitize(duration_train, bins, right=True)
bin_test = np.digitize(duration_test,bins,right = True) # bins -> train

print(bins)

N_train = len(duration_train)
bin_matrix = np.zeros((N_train,101))

N_test = len(duration_test)
bin_matrix_test = np.zeros((N_test,101))



all_sub_bins = np.array([
    np.quantile(plays_train[bin_train == i], np.linspace(0, 1, 101)) 
    if np.sum(bin_train == i) > 0 else np.zeros(101)  
    for i in range(1, 31)
])


#print(all_sub_bins[:5])


for i in range(1, 31):  
    mask = bin_train == i  
    bin_matrix[mask, :] = all_sub_bins[i - 1]   

for i in range(1, 31):  
    mask = bin_test == i 
    bin_matrix_test[mask, :] = all_sub_bins[i - 1]  # bin(train)

small_bin_train = np.zeros(len(duration_train), dtype=int)
small_bin_test = np.zeros(len(duration_test), dtype=int)

for i in range(1, 31):  
    mask_train = bin_train == i  
    mask_test = bin_test == i  
    
    if np.sum(mask_train) > 0:  # size > 0
        small_bin_train[mask_train] = np.digitize(plays_train[mask_train], all_sub_bins[i - 1], right=True)
    
    if np.sum(mask_test) > 0:  # bin(train)
        small_bin_test[mask_test] = np.digitize(plays_test[mask_test], all_sub_bins[i - 1], right=True)





# print("big_bin_train:", bin_train.shape)   # (N_train,)
# print("small_bin_train:", small_bin_train.shape)   # (N_train,)

# print("big_bin_test:", bin_test.shape)   # (N_test,)
# print("small_bin_test:", small_bin_test.shape)   # (N_test,)


# print(bin_train[:5])
# print(bin_test[:5])
# print(small_bin_train[:5])
# print(small_bin_test[:5])
# print(duration_train[:5])
# print(bin_matrix[:5])
# print(bin_matrix.shape)  # (N, 31)
# print(bin_matrix_test.shape)
#-------

#-------

def rff_map(X: torch.Tensor, D: int, sigma: float) -> torch.Tensor:
    B, d = X.shape
    gamma = 1.0 / (2.0 * sigma**2)
    W = torch.randn(d, D, device=X.device) * math.sqrt(2.0 * gamma)
    b = 2.0 * math.pi * torch.rand(1, D, device=X.device)
    proj = X @ W  # (B, D)
    proj = proj + b  # (B, D)
    rff = torch.cat([torch.cos(proj), torch.sin(proj)], dim=1)  # (B, 2D)
    rff = rff / math.sqrt(D)
    return rff


def hsic_loss_rff(
    X: torch.Tensor,
    Y: torch.Tensor,
    rff_dim: int = 64,
    sigma_x: float = 1,
    sigma_y: float = 1
) -> torch.Tensor:

    torch.manual_seed(1)
    X = X.flatten(start_dim=1)
    Y = Y.flatten(start_dim=1)
    B = X.shape[0]
    if B <= 3:
        return X.new_zeros(1, requires_grad=True)

    PhiX = rff_map(X, rff_dim, sigma_x)  # (B, 2*rff_dim)
    PhiY = rff_map(Y, rff_dim, sigma_y)  # (B, 2*rff_dim)

    # 2. HSIC = 1/(n^2) sum_{i,j} k(x_i, x_j) l(y_i, y_j)
    #    ~ 1/(n^2) sum_{i,j} <PhiX_i, PhiX_j> * <PhiY_i, PhiY_j>
    #    = 1/(n^2) sum_{i,j} dot(PhiX_i * PhiY_i, PhiX_j * PhiY_j)
    #    = 1/(n^2) [ (sum_{i} PhiX_i * PhiY_i) · (sum_{j} PhiX_j * PhiY_j) ]
    #    = 1/(n^2) || sum_{i} [PhiX_i * PhiY_i] ||^2
    Psi = PhiX * PhiY  # (B, 2*rff_dim) element-wise
    Psi_sum = Psi.sum(dim=0)  # (2*rff_dim)
    hsic_approx = Psi_sum.dot(Psi_sum) / (B*B)

    hsic_approx = torch.clamp(hsic_approx, min=0.0)
    return hsic_approx

def hsic_loss(
    X: torch.Tensor,
    Y: torch.Tensor,
    sigma_x: float = -1,
    sigma_y: float = -1
) -> torch.Tensor:
    """
    If use RFF: O(B * D)
    B: batch_size, D: RFF dim
    """

    X = X.flatten(start_dim=1)
    Y = Y.flatten(start_dim=1)

    b = X.shape[0]
    if b <= 3:
        # batch_size < 3: return 0
        return X.new_zeros(1, requires_grad=True)

    # Gram
    xx = X @ X.T    # (b, b)
    rx = xx.diag().unsqueeze(0).expand_as(xx)
    dxx = rx.T + rx - 2*xx

    if sigma_x < 0:
        vx = torch.quantile(dxx, 0.5)
    else:
        vx = sigma_x**2
    mask = 1.0 - torch.eye(b, device=X.device)
    K = torch.exp(-0.5 * dxx / vx) * mask

    yy = Y @ Y.T
    ry = yy.diag().unsqueeze(0).expand_as(yy)
    dyy = ry.T + ry - 2*yy

    if sigma_y < 0:
        vy = torch.quantile(dyy, 0.5)
    else:
        vy = sigma_y**2
    L = torch.exp(-0.5 * dyy / vy) * mask

    KL = K @ L
    trace = KL.trace()

    second_term = K.sum() * L.sum() / ((b - 1) * (b - 2))
    third_term = KL.sum() / (b - 2)

    hsic = trace + second_term - 2.0 * third_term
    hsic /= b * (b - 3)

    # hsci >= 0
    hsic = torch.clamp(hsic, min=0.0)

    return hsic


def micro_hsic_loss(repr_batch, dur_batch, pred, label, buck, micro_bs=128, reduce="sum"):
    dyn_fix = True
    B = repr_batch.size(0)
    if B % micro_bs != 0:
        return 0
    num_chunks = B // micro_bs

    repr_chunks = repr_batch.split(micro_bs, dim=0)
    dur_chunks  = dur_batch.split(micro_bs, dim=0)
    res_value = 0
    if dyn_fix:   
        err = pred - label
        reg = 0
        thera = 0.1 + 0.3 * buck / 30
        idx = (err.abs() > thera)
        res = (err.abs() - thera)[idx] * (err.abs() - thera)[idx] / 2
        res_value = res.sum()
    loss_list = []
    for r, d in zip(repr_chunks, dur_chunks):
        loss_list.append(hsic_loss(r, d))       
    if reduce == "sum":
        return torch.stack(loss_list).sum() * 100 - res_value
    else:
        raise ValueError("reduce: 'sum")


# fix seed
seed = 1
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
random.seed(seed)
np.random.seed(seed)
#-------


print(train_feats_selected.shape)
print(test_feats_selected.shape)
train_durations = train_feats_selected[:, -3]
test_durations = test_feats_selected[:, -3]
durations = np.concatenate((train_durations, test_durations), axis=0)
encoder = LabelEncoder()
unique_sorted_durations = np.sort(np.unique(durations))
encoder.fit(unique_sorted_durations)
encoded_duration = encoder.transform(durations)
encoded_train_duration = encoded_duration[:len(train_feats_selected)]
encoded_test_duration = encoded_duration[len(train_feats_selected):]
train_feats_selected = np.column_stack((train_feats_selected, encoded_train_duration))
test_feats_selected = np.column_stack((test_feats_selected, encoded_test_duration))
print(train_feats_selected.shape)
print(test_feats_selected.shape)


feats_all = np.concatenate((train_feats_selected, test_feats_selected), axis=0)
max_values_per_column = np.amax(feats_all, axis=0)

play_time = train_feats_selected[:, -5]

train_feats_selected = np.hstack((train_feats_selected, bin_train[:,np.newaxis], small_bin_train[:,np.newaxis]))
test_feats_selected = np.hstack((test_feats_selected, bin_test[:,np.newaxis], small_bin_test[:,np.newaxis]))


print(train_feats_selected.shape)
print(test_feats_selected.shape)



train_dataset = Dataset(train_feats_selected, is_train=True)
test_dataset = Dataset(test_feats_selected, is_train=False)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True) 
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

model = Model(max_values_per_column, feat_dim, dropout)

model.cuda()
# begins_tensor = begins_tensor.cuda()
# ends_tensor = ends_tensor.cuda()
optimizer = Adam(model.parameters(), lr=learning_rate, betas=(0.9, 0.999))
best_mae = float('inf')
best_xauc = 0
best_model = None



def get_final_prediction(buck, label):
    """
    
    buck: Tensor (N,)
    label: Tensor (N,)
    all_sub_bins: np.array (30, 101) 
    
    Returns: pred_values: Tensor (N,)
    """
    N = buck.shape[0]
    pred_values = torch.zeros(N, dtype=torch.float32).cuda()
    
    for i in range(1, 31):  
        mask = buck == i  
        if mask.sum() > 0:
            bin_edges = torch.tensor(all_sub_bins[i - 1], dtype=torch.float32).cuda()
            indices = label[mask] * 100  # 0~1 -> 0~100
            index_low = indices.floor().long()
            index_high = (index_low + 1).clamp(max=100)
            weight = indices - index_low
            #pred_values[mask] = bin_edges[indices]  # find final value
            pred_values[mask] = bin_edges[index_low] + weight * (bin_edges[index_high] - bin_edges[index_low])
    
    return pred_values



for epoch in range(1, num_epochs+1):
    model.train()
    all_pred_list1 = []
    all_ground_list1 = []
    for num_step, (X_batch, X_dis, qmsk_batch, imsk_batch, durations, play_times) in enumerate(train_loader, 1):
        buck = X_dis[:,0].cuda()
        label = X_dis[:,1].cuda()
        X_batch = X_batch.cuda()
        qmsk_batch = qmsk_batch.cuda()
        imsk_batch = imsk_batch.cuda()
        durations = durations.cuda()
        play_times = play_times.cuda()
        optimizer.zero_grad()
        
        emb_x, pred_train = model(X_batch, qmsk_batch, imsk_batch) # (batch_size, wr_bucknum)
        pred_final = get_final_prediction(buck, pred_train.squeeze())
        encoded_playtime = pred_final

        loss_huber = F.huber_loss(pred_train.squeeze(), label / 100, reduction='sum', delta=1)
        loss_hsic = micro_hsic_loss(emb_x, durations, pred_train.squeeze(), label / 100, buck, micro_bs=128, reduce="sum")
        total_loss = loss_huber + loss_hsic
        total_loss.backward()
        optimizer.step()
        all_pred_list1.append(encoded_playtime.detach().cpu().numpy())
        all_ground_list1.append(play_times.detach().cpu().numpy())
        if num_step % 1000 == 0 or num_step == 1:
            print(f"Step {num_step}, Loss = {total_loss.item()}")
            ytime = play_times.to('cpu').detach().numpy()
            ptime = encoded_playtime.to('cpu').detach().numpy()
            for i in range(5):
                print(ytime[i], ptime[i])
                
    #all_pred1 = np.concatenate(all_pred_list1).reshape(-1)
    #all_yy1 = np.concatenate(all_ground_list1).reshape(-1)    
    #xauc = round(xauc_score(all_yy1, all_pred1), 4)
    #print(f"{epoch}/{num_epochs} epoch train XAUC is {xauc}")
    #mae = round(np.mean(np.abs(all_pred1 - all_yy1)), 4)
    #print(f"{epoch}/{num_epochs} epoch train MAE is {mae}")
    
    print(f"{epoch}/{num_epochs} Optimization Finished!")
    model.eval()
    all_pred_list = []
    all_ground_list = []
    all_dur = []
    with torch.no_grad(): 
        for X_batch, X_dis, qmsk_batch, imsk_batch, durations, play_times in test_loader:
            buck = X_dis[:,0].cuda()
            label = X_dis[:,1].cuda()
            label = label.cuda()
            X_batch = X_batch.cuda()
            qmsk_batch = qmsk_batch.cuda()
            imsk_batch = imsk_batch.cuda()
            durations = durations.cuda()
            play_times = play_times.cuda()
            optimizer.zero_grad()
            
            _, pred_train = model(X_batch, qmsk_batch, imsk_batch) 
    
    
            ptime_test = get_final_prediction(buck, pred_train.squeeze())

            all_pred_list.append(ptime_test.cpu().numpy())
            all_ground_list.append(play_times.cpu().numpy())
            all_dur.append(durations.cpu().numpy())
    all_pred = np.concatenate(all_pred_list).reshape(-1)
    all_yy = np.concatenate(all_ground_list).reshape(-1)
    all_dur = np.concatenate(all_dur).reshape(-1)

    print(all_pred.shape[0])
    print(all_yy.shape[0])
    print(all_dur.shape[0])
    # if epoch == 20:
    #     np.save('all_yy.npy',all_yy)
    #     np.save('all_pred.npy',all_pred)
    #     np.save('all_dur.npy',all_dur)

    xauc = round(xauc_score(all_yy, all_pred), 4)
    print(f"{epoch}/{num_epochs} epoch XAUC is {xauc}")
    mae = round(np.mean(np.abs(all_pred - all_yy)), 4)
    print(f"{epoch}/{num_epochs} epoch MAE is {mae}")
    for i in range(5):
        print(all_yy[i], all_pred[i])
    if mae < best_mae:
        best_mae = mae
        best_xauc = xauc
        best_model = copy.deepcopy(model.state_dict())
        #torch.save(best_model, 'checkpoints_kuai/best_model.pth')
        print("save!!!")

    print(f"Best XAUC is {best_xauc} \nBest MAE is {best_mae}")