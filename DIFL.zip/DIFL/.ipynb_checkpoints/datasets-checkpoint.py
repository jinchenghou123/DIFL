from torch.utils.data import Dataset
import torch
import hashlib

    
class Dataset(Dataset):
    def __init__(self, features, is_train):
        self.features = features
        self.is_train = is_train

    def __len__(self):
        return self.features.shape[0]

    def __getitem__(self, idx):
        if self.is_train and idx >= self.features.shape[0]:
            idx = idx % self.features.shape[0]
        alist = self.features[idx, :].tolist()

        features = torch.tensor(alist[:24] + [alist[-3]], dtype=torch.int32)
        dis = torch.tensor(alist[-2:], dtype = torch.float32)
        qmsk = torch.tensor(alist[24:43], dtype=torch.float32)
        imsk = torch.tensor(alist[43:48], dtype=torch.float32)
        video_durations = torch.tensor([self.features[idx, -3]], dtype=torch.float32)
        play_time = torch.tensor([self.features[idx, -7]], dtype=torch.float32)
    
        return features, dis, qmsk, imsk, video_durations, play_time
    


