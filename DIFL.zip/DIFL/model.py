import torch.nn as nn
import torch
import torch.nn.functional as F
from torchfm.layer import FeaturesEmbedding, CrossNetwork, MultiLayerPerceptron
    

class Model(nn.Module):
    def __init__(self, max_values_per_column, feat_dim, dropout):
        super().__init__()


        # self.W_q = nn.Linear(feat_dim, feat_dim, bias = False)
        # self.W_k = nn.Linear(feat_dim, feat_dim, bias = False)
        # self.W_v = nn.Linear(feat_dim, feat_dim, bias = False)
        
        self.user_id_embedding = nn.Embedding(int(max_values_per_column[0])+1, feat_dim)
        self.user_fea_embedding = nn.ModuleList([
            nn.Embedding(int(max_values_per_column[i])+1, feat_dim) for i in range(1, 19)
        ])
        self.item_id_embedding = nn.Embedding(int(max_values_per_column[19])+1, feat_dim)
        self.item_fea_embedding = nn.Embedding(int(max(max_values_per_column[20:24]))+1, feat_dim)
        self.item_duration_embedding = nn.Embedding(int(max_values_per_column[-1])+1, feat_dim)

        self.cn = CrossNetwork(64, 3)
        self.mlp = MultiLayerPerceptron(64, [64,64,64], dropout, output_layer=False)

        self.fc1 = nn.Linear(feat_dim * 5, 1024)
        self.fc2 = nn.Linear(1024, 512)
        self.fc3 = nn.Linear(512, 256)
        self.fc4 = nn.Linear(256, 1) 
        
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, x, qmsk, imsk):

       
        usr_id = self.user_id_embedding(x[:, 0].unsqueeze(1))
        usr_fea = torch.cat([self.user_fea_embedding[id](x[:, i].unsqueeze(1)) for id, i in enumerate(range(1,19))], dim=1)
        item_id = self.item_id_embedding(x[:, 19].unsqueeze(1))
        item_fea = torch.cat([self.item_fea_embedding(x[:, i].unsqueeze(1)) for i in range(20,24)], dim=1)
        item_duration = self.item_duration_embedding(x[:, 24].unsqueeze(1))

        
        usr_fea = torch.cat([usr_id, usr_fea], dim=1)
        item_fea = torch.cat([item_id, item_fea], dim=1)

        qmsk = qmsk.unsqueeze(-1)
        imsk = imsk.unsqueeze(-1)
        
        query_embeddings = usr_fea * qmsk
        item_embeddings = item_fea * imsk        
        #item_embeddings = torch.cat([item_embeddings, item_duration], dim=1)
        query_sum = query_embeddings.sum(1) / qmsk.sum(1)
        item_sum = item_embeddings.sum(1) / imsk.sum(1)


        # self-attention
        
        # Q = self.W_q(query_sum)
        # K = self.W_k(item_sum)
        # V = self.W_v(item_sum)

        # attention_scores = torch.matmul(Q, K.T) / (query_sum.shape[1] ** 0.5)
        # attention_weights = torch.softmax(attention_scores, dim = -1)

        # attention_item = torch.matmul(attention_weights, V)
        
        # x = torch.cat([query_sum, attention_item], dim = -1)
        
        x = torch.cat([query_sum, item_sum], dim=1)
        
        x_l1 = self.cn(x)
        h_l2 = self.mlp(x)
        x = torch.cat([x_l1, h_l2], dim=1)
        emb_x = x
        i_trans = item_duration.sum(1)
        x = torch.cat([x, i_trans],dim=1)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        x = F.relu(self.fc3(x))
        logits = self.fc4(x)
        return emb_x, torch.sigmoid(logits)
    